$(document).ready(function() {
	$('.skitter-large').skitter({     
	});
});
